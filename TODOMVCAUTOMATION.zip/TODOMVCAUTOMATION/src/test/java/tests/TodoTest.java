package tests;

import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.TodoPages;

public class TodoTest {
	WebDriver driver;
	TodoPages toDopages;
	SoftAssert softAssert;
	Logger logger;
	String expItem;

	@BeforeClass
	public void setUp() {
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Test-User\\Downloads\\chromedriver_win32");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe path on your laptop");
		driver = new ChromeDriver(options);
		String url = "https://todomvc.com/examples/angular/dist/browser/#/completed";
		//driver = new ChromeDriver();
		driver.navigate().to(url);
		// driver.get("https://todomvc.com/examples/angular/dist/browser/#/completed");
	}
	
	@Test(priority=0)
	public void addToDo() {
		toDopages = new TodoPages(driver);
		expItem = "Drink water every hour";
		toDopages.getToDoInputTxtBox().sendKeys("Drink water every hour");
		toDopages.getToDoInputTxtBox().sendKeys(Keys.ENTER);
		String actItemstr = "//input[@type='checkbox']/following-sibling::label[contains(text(),'"+expItem+"')]";
		WebElement actItemEle = driver.findElement(By.xpath(actItemstr));
		String actItem = actItemEle.getText();
		softAssert.assertEquals(actItem, expItem);
		//logger statements
		boolean verifyItemAdded = actItemstr.equals(expItem);
		System.out.println("The expected item added successfiully: "+expItem+" "+actItem+" "+verifyItemAdded);
		String actToDoCount = toDopages.getToDoCount().getText();
		softAssert.assertEquals(actToDoCount, "1");
		boolean verifyToDoCount = actToDoCount.equals("1");
		System.out.println("The todo count should be as expected: "+"1"+" "+actToDoCount+" "+verifyToDoCount);
	}
	
	@Test(dependsOnMethods = {"addToDo"})
	public void markItem() {
		String checkBoxStr = "//*[contains(text(),'"+expItem+"')]/preceding-sibling::input";
		WebElement actItemEle = driver.findElement(By.xpath(checkBoxStr));
		actItemEle.click();
		//verify the toDO item is marked or not check the class attribute changed to completed
		String toDoListStr = "//*[contains(text(),'"+expItem+"')]/ancestor::li";
		WebElement toDoListStatus = driver.findElement(By.xpath(toDoListStr));
		String actStatus = toDoListStatus.getAttribute("class");
		String expStatus = "completed";
		softAssert.assertEquals(actStatus, expStatus);
		boolean verifyItemIsCrossed = actStatus.equals(expStatus);
		System.out.println("Verify the item is marked successfiully: "+expStatus+" "+actStatus+" "+verifyItemIsCrossed);
		String actToDoCount = toDopages.getToDoCount().getText();
		//we can create reusable method
		softAssert.assertEquals(actToDoCount, "0");
		boolean verifyToDoCount = actToDoCount.equals("0");
		System.out.println("The todo count should be as expected: "+"0"+" "+actToDoCount+" "+verifyToDoCount);
	}
	
	@Test(dependsOnMethods = {"addToDo", "markItem"})
	public void deleteItem() {
		toDopages.getdeleteItem().click();
		//else use java script click to force delete
//		JavascriptExecutor jse = (JavascriptExecutor) driver;
//		jse.executeScript("arguments[0].click();", toDopages.getDeleteItem());
		//verify item is removed
		String expPlaceHolder = "What needs to be done?";
		String actPlaceHolder = toDopages.getToDoInputTxtBox().getAttribute("placeholder");
		softAssert.assertEquals(actPlaceHolder, expPlaceHolder);
		boolean verifyItemsRemoved = actPlaceHolder.equals(expPlaceHolder);
		System.out.println("Verify the item is marked successfiully: "+expPlaceHolder+" "+actPlaceHolder+" "+verifyItemsRemoved);
	}
	
	@Test(dependsOnMethods = {"addToDo"})
	public void filterToDo() {
		//verify Active button
		toDopages.getactiveBtn().click();
		String expItemStr = "//*[contains(text(),'"+expItem+"')]";
		WebElement actItemEle = driver.findElement(By.xpath(expItemStr));
		String actActiveItem = actItemEle.getText();
		softAssert.assertEquals(actActiveItem, expItem);
		boolean verifyActiveItems = actActiveItem.equals(expItem);
		System.out.println("Verify the active item should be displayed successfiully as expected: "+expItem+" "+actActiveItem+" "+verifyActiveItems);
		List<WebElement> actActiveItemList =  driver.findElements(By.xpath("//*[contains(text(),'"+expItem+"')]/ancestor::li")); 
		boolean isActiveItemsPresent = actActiveItemList.size()>0;
		System.out.println("Verify active items are shown: "+true+" "+isActiveItemsPresent+" "+isActiveItemsPresent);
		toDopages.getcompletedBtn().click();
		String expItemStr1 = "//*[contains(text(),'"+expItem+"')]";
		WebElement actItemEle1 = driver.findElement(By.xpath(expItemStr1));
		String actActiveItem1 = actItemEle1.getText();
		softAssert.assertEquals(actActiveItem1, expItem);
		boolean verifyCompletedItems1 = actActiveItem1.equals(expItem);
		System.out.println("Verify the completed item should be displayed successfiully as expected: "+expItem+" "+actActiveItem1+" "+verifyCompletedItems1);		
		List<WebElement> actCompletedItemList =  driver.findElements(By.xpath("//*[contains(text(),'click')]/ancestor::li[@class='completed']")); 
		boolean isCompletedItemsPresent = actCompletedItemList.size()>0;
		System.out.println("Verify completed items are shown: "+true+" "+isCompletedItemsPresent+" "+isCompletedItemsPresent);
	}
	
	@AfterClass
	public void tearDown() {
		driver.close();
	}
	
	
	
	
	
	
	
	
}
