package framework;

public class BaseUtil {

}
