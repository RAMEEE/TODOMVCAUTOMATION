package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TodoPages {
	WebDriver driver;

	public TodoPages(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[contains(@placeholder, 'What needs')]")
	private WebElement toDoInputTxtBox;
	
	@FindBy(xpath = "//*[@class='todo-count']/strong")
	private WebElement toDoCount;
	
	
	@FindBy(xpath = "//button[@class='destroy']")
	private WebElement deleteItem;
	
	@FindBy(xpath = "//a[contains(text(),'Active')]")
	private WebElement activeBtn;
		
	@FindBy(xpath = "//a[contains(text(),'Compl')]")
	private WebElement completedBtn;
	
	
	@FindBy(xpath = "//*[contains(@class,'todo-list')]//li")
	private List<WebElement> listItems;
	
	public WebElement getToDoInputTxtBox() {
		return toDoInputTxtBox;
	}
	
	public WebElement getToDoCount() {
		return toDoCount;
	}
	
	public WebElement getdeleteItem() {
		return deleteItem;
	}
	
	public WebElement getactiveBtn() {
		return activeBtn;
	}
	
	public WebElement getcompletedBtn() {
		return completedBtn;
	}
	
	public List<WebElement> getlistItems() {
		return listItems;
	}
}
